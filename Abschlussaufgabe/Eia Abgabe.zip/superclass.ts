namespace Abschluss {
    export class Superclass {
        x: number;
        y: number;
        radius: number;
        color: string; 
        positionX: number;
        positionY: number;
        
        
        constructor( ) {
               //steht nix drin   
            this.setRandomPosition();
            
        }
        setRandomPosition():void {
            //stehtnixdrin
            
            }
        takePosition(): void{
            //steht nix drin
           }
        move(): void {
            //steht nix drin    
        }
        
        draw(): void {
           //steht nix drin         
        }
    } 
}