var Abschluss;
(function (Abschluss) {
    class Superclass {
        constructor() {
            //steht nix drin   
            this.setRandomPosition();
        }
        setRandomPosition() {
            //stehtnixdrin
        }
        takePosition() {
            //steht nix drin
        }
        move() {
            //steht nix drin    
        }
        draw() {
            //steht nix drin         
        }
    }
    Abschluss.Superclass = Superclass;
})(Abschluss || (Abschluss = {}));
//# sourceMappingURL=superclass.js.map